$(document).ready(function(){

    $('.modal-request-show').click(function(){
        $('#modal-request').modal('show');
    });

    $('.tel-inp').inputmask({
        "mask": "+7 (999) 999-99-99"
        , "placeholder": "_"
        , showMaskOnHover: false
        , showMaskOnFocus: true
    });
   
    
});

